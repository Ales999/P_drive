''' 
Dummy class 
'''

class dummy():
	"""docstring for dummy"""
	def __init__(self, edit):
		super(dummy, self).__init__()
		self.edit = edit
	def run(self, edit):
		print 'dummy'
		
