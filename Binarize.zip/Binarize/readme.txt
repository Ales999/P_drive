﻿Binarize for Arma 3

Usage:
binarize [options] source destination [wildcard]

Options:
	-textures=<folder> copy all used textures to folder
	-exclude=<file> file contains list of files to exclude
	-norecurse do not traverse any subdirectories
	-addon=<addon folder> config is loaded from this folder
	-binpath=<folder> placement of bin directory with the main config
	-FP1 output in format for FP1 (working just on *.wrp)
	-always binarize even if not necessary based on timestamps
	-silent never display any message box, never wait for any user input
	-maxProcesses=<n> allow spawning max. n child processes for conversions
	-targetBonesInterval=<n> how many bones are allowed in one section when binarizing p3d file (default: 55)
	-skeleton=<name> which skeleton should be used for rtm binarization (default: OFP2_ManSkeleton)
	-texheader only creates texture headers from source dir, file is placed in destination dir
	-appId sets the appId of the asset to given value (game/DLC). This ID is later used by the game to check ownership of the asset
	-disablePreBinDataForWRP force to used only non-binarized P3Ds when converting map(*.wrp)


========

    © 2013-2017 Bohemia Interactive a.s.

    All rights reserved.

	See http://community.bistudio.com/wiki/Binarize for more details of usage